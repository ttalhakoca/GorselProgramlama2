// oyunYonetici.cs
using UnityEngine;

public class oyunYonetici : MonoBehaviour
{
    GameObject anaCember;
    GameObject donenCember;

    public Animator animator;

    void Start()
    {
        // Tag'lerle nesneleri bul
        anaCember = GameObject.FindGameObjectWithTag("anaCember");
        donenCember = GameObject.FindGameObjectWithTag("donenCember");

        // Hata kontrol�:
        if (anaCember == null)
            Debug.LogError("ANA �EMBER BULUNAMADI! Tag'i kontrol et: 'anaCember'");

        if (donenCember == null)
            Debug.LogError("D�NEN �EMBER BULUNAMADI! Tag'i kontrol et: 'donenCember'");
    }

    void Update()
    {
        // Bo� b�rak
    }

    public void oyunBitti()
    {
        // Sadece nesneler bulunmu�sa kapatma i�lemini yap.
        if (donenCember != null)
        {
            // D�nmeyi durdur
            donenCember.GetComponent<donenCemberKod>().enabled = false;
        }

        if (anaCember != null)
        {
            // At��� durdur
            anaCember.GetComponent<anaCember>().enabled = false;
        }

        animator.SetTrigger("oyunBitti");


    }
}